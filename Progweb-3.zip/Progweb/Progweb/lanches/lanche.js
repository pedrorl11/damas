function cringe(){
    let n = document.getElementById("numero").value;
    string= "";

    for(var i = 1; i <= n; i++){
        string += i +" "
        var text = (string +  "<br>")
        document.write(text)
    }
}

